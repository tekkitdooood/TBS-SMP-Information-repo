ServerEvents.recipes(event => {
    event.campfireCooking('thebrokencontent:cooked_trans_beef', 'thebrokencontent:trans_beef', 0.25, 600)
})