ServerEvents.recipes(event => {
    event.custom({
        "type": "create:haunting",
        "ingredients": [
            {"item": "minecraft:obsidian"}
            ],
        "results": [
            {"id": "minecraft:crying_obsidian"}
            ]
        }
    )
})