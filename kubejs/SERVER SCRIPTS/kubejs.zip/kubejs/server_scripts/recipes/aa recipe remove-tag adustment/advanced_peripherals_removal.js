ServerEvents.recipes(event => {
    event.remove({output: "advancedperipherals:player_detector"})
    event.remove({output: "advancedperipherals:geo_scanner"})
})