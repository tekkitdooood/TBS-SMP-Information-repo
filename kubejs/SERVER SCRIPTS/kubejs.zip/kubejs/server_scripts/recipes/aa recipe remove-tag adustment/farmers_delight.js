ServerEvents.recipes(event => {
    event.remove({output: 'farmersdelight:chocolate_pie', type: 'create:filling'})
})