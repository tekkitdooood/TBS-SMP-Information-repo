ServerEvents.recipes(event => {
    crusher('c:ender_eye', 'electrodynamics:dustendereye', event)
})