ServerEvents.recipes(event => {
    event.smelting('supplementaries:ash', '#minecraft:saplings')
})